package com.finacular.constants;

public class ConstantsOfProjects {
	public static final String FINAL_PATH_OF_EXCCELSHEET = "C:\\Users\\mglocadmin\\Downloads\\data2.xls";
	public static final String DRIVER = "org.postgresql.Driver";
	public static final String POSTGRES_PATH_TO_CONNECT_LOCAL_DB = "jdbc:postgresql://localhost:5432/postgres";
	public static final String POSTGRES_USER_NAME = "postgres";
	public static final String POSTGRES_PASSWORD = "database";
	public static final String POSTGRES_PATH_TO_CONNECT_AWS_DB = "jdbc:postgresql://findb-1.c6v9409usa68.us-east-2.rds.amazonaws.com/postgres";
	public static final String POSTGRES_USER_NAME_OF_AWS = "gritcapital";
	public static final String POSTGRES_PASSWORD_OF_AWS = "grit1234";
	public static final String CONNECT_TO_LOACAL = "LOACAL";
	public static final String CONNECT_TO_AWS = "AWS";

}
